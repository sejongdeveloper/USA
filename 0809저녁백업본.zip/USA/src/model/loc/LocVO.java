package model.loc;

public class LocVO {

	private String loc_name;
	private String loc_contents;
	private String loc_filename;
	private String loc_regname;
	
	public String getLoc_name() {
		return loc_name;
	}
	public void setLoc_name(String loc_name) {
		this.loc_name = loc_name;
	}
	public String getLoc_contents() {
		return loc_contents;
	}
	public void setLoc_contents(String loc_contents) {
		this.loc_contents = loc_contents;
	}
	public String getLoc_filename() {
		return loc_filename;
	}
	public void setLoc_filename(String loc_filename) {
		this.loc_filename = loc_filename;
	}
	public String getLoc_regname() {
		return loc_regname;
	}
	public void setLoc_regname(String loc_regname) {
		this.loc_regname = loc_regname;
	}
	
}
