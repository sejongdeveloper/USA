package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import model.tra.TradeBoardreplyDAO;
import model.tra.TradeBoardreplyVO;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		int num =Integer.parseInt(request.getParameter("num")) ;
		PrintWriter out=response.getWriter();
		out.write(getJson(10));
		
		
	}

	public String getJson(int num) {
		TradeBoardreplyDAO dao=new TradeBoardreplyDAO();
		ArrayList<TradeBoardreplyVO> list=new ArrayList<TradeBoardreplyVO>();
		list=dao.getreplylist(10);
		

		
		StringBuffer result=new StringBuffer();
		result.append("{\result\":[");
		for (int i = 0; i < list.size(); i++) {
			
		result.append("[{\"value\": \""+list.get(0).getTrarep_num()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_tranum()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_contents()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_writer()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_writerrep()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_numref()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_numref_lv()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_alive()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_writerrepwriter()+"\"},");
		result.append("{\"value\": \""+list.get(0).getTrarep_date()+"\"}],");
		}
		result.append("]}");
		
		
		return result.toString();
	}
}
