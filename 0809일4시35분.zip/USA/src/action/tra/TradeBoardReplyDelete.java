package action.tra;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Command;
import model.tra.TradeBoardreplyDAO;

public class TradeBoardReplyDelete implements Command{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int trarep_num=Integer.parseInt(request.getParameter("trarep_num"));
		int trarep_tranum=Integer.parseInt(request.getParameter("tradeboardnum"));
		System.out.println(trarep_tranum+"여기는 리플 삭제");
		TradeBoardreplyDAO dao=new TradeBoardreplyDAO();
		dao.replydelete(trarep_num);
		return "/view/tra/content.do?num="+trarep_tranum;
	}

}
