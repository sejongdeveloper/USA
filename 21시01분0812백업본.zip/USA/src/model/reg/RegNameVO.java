package model.reg;

public class RegNameVO {
    private String regName;
    private String regNameEng;
    private String regGmt;
    private int regFlight;
    
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getRegNameEng() {
		return regNameEng;
	}
	public void setRegNameEng(String regNameEng) {
		this.regNameEng = regNameEng;
	}
	public String getRegGmt() {
		return regGmt;
	}
	public void setRegGmt(String regGmt) {
		this.regGmt = regGmt;
	}
	public int getRegFlight() {
		return regFlight;
	}
	public void setRegFlight(int regFlight) {
		this.regFlight = regFlight;
	}
    
    
}
